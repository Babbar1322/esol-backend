<p align="center"><a href="https://laravel.com" target="_blank"><img src="https://raw.githubusercontent.com/laravel/art/master/logo-lockup/5%20SVG/2%20CMYK/1%20Full%20Color/laravel-logolockup-cmyk-red.svg" width="400"></a></p>

# ESOL Backend

ESOL (English School of Languages) is a language school based in the UK. This project is a backend for the ESOL website. It is built using Laravel 8 and MySQL.

- [ESOL - Student Panel](https://esol-by-gs.web.app)
- [Main Panel](https://raazbook.com/esol-new)
