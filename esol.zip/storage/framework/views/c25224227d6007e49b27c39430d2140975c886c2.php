<?php $__env->startSection('content'); ?>
    <div class="modal fade" id="confirmation" tabindex="-1" aria-labelledby="confirmationModal" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    Are You Sure?<br /><b>You Want to Delete This Test?</b>
                </div>
                <div class="modal-footer py-1">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <a href="#" id="deleteBtn" class="btn btn-danger">Delete</a>
                </div>
            </div>
        </div>
    </div>
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div>
            <ol class="breadcrumb fs-sm mb-1">
                <li class="breadcrumb-item"><a>Test</a></li>
                <li class="breadcrumb-item active" aria-current="page">All Tests</li>
            </ol>
            <h4 class="main-title mb-0">List of All Tests</h4>
        </div>
        <div>
            <a href="<?php echo e(route('admin.add-new-test')); ?>" class="btn btn-primary rounded-pill shadow px-4">Add New Test</a>
            <a href="<?php echo e(route('admin.combine-tests')); ?>" class="btn btn-success rounded-pill shadow px-4 ms-3">Combine Tests</a>
        </div>
    </div>

    <div class="card card-one mt-3 shadow">
        <div class="card-body p-3">
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('message')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">Sr.</th>
                        <th scope="col">Name</th>
                        <th scope="col">Type</th>
                        <th scope="col">Groups</th>
                        <th scope="col">Total Questions</th>
                        <th scope="col">Added On</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(count($data) > 0): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($test->test_name); ?></td>
                            <td style="text-transform: capitalize;"><?php echo e($test->test_type); ?></td>
                            <td><?php echo e(count($test->test_groups)); ?></td>
                            <td><?php echo e($test->total_questions); ?></td>
                            <td><?php echo e($test->created_at); ?></td>
                            <td>
                                <?php if($test->status === 0): ?>
                                    <a href="<?php echo e(route('admin.add-test-questions', ['id' => $test->id])); ?>"
                                       class="btn btn-success rounded-pill">Add Questions</a>
                                    <a href="<?php echo e(route('admin.add-dnd-questions', ['id' => $test->id])); ?>"
                                       class="btn btn-success rounded-pill">Add Drag and Drop Questions</a>
                                    <a href="<?php echo e(route('change-test-status', ['id' => $test->id, 'status' => 1])); ?>"
                                        class="btn btn-primary rounded-pill">Publish</a>
                                    <a href="<?php echo e(route('admin.add-test-groups', ['id' => $test->id])); ?>"
                                        class="btn btn-primary rounded-pill">Add Test Groups</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('change-test-status', ['id' => $test->id, 'status' => 0])); ?>" class="btn btn-secondary rounded-pill">Hide</a>
                                <?php endif; ?>
                                <button type="button" class="btn btn-danger deleteTest rounded-pill" test-id="<?php echo e($test->id); ?>"
                                    data-bs-toggle="modal" data-bs-target="#confirmation">
                                    <i class="ri-delete-bin-6-fill"></i>
                                </button>
                            </td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center"><h3>No Tests Found</h3></td>
                    </tr>
                    <tr>
                        <td colspan="7" class="text-center"><a href="<?php echo e(route('admin.add-new-test')); ?>" class="btn btn-primary px-3 rounded-pill shadow">Add New Test</a></td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?php echo e(asset('dashboard/lib/jquery/jquery.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.deleteTest').click(function() {
                $('#deleteBtn').attr('href', '<?php echo e(route('delete-test')); ?>' + "?id=" + $(this).attr(
                    'test-id'));
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gursahb/Projects/Laravel/esol-test/resources/views/dashboard/allTests.blade.php ENDPATH**/ ?>