<html lang="en">

<head>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Meta -->
    <meta name="description" content="">
    <meta name="author" content="Webcyst">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('dashboard/img/favicon.png')); ?>">

    <title>ESOL - Login</title>

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/lib/remixicon/fonts/remixicon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/lib/jqvmap/jqvmap.min.css')); ?>">

    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('dashboard/css/style.min.css')); ?>">
</head>

<body class="page-sign">

    <div class="card card-sign">
        <div class="card-header">
            <a href="#" class="header-logo mb-4">ESOL</a>
            <h3 class="card-title">Sign In</h3>
            <p class="card-text">Welcome back! Please signin to continue.</p>
        </div><!-- card-header -->
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="mb-4">
                    <label for="email" class="form-label"><?php echo e(__('Email Address')); ?></label>
                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                    <label for="password" class="form-label d-flex justify-content-between"><?php echo e(__('Password')); ?> </label>
                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- <input type="password" class="form-control" placeholder="Enter your password"> -->
                </div>
                <button type="submit" class="btn btn-primary btn-sign">
                    <?php echo e(__('Login')); ?>

                </button>
            </form>
            <!-- <button class="btn btn-primary btn-sign">Sign In</button> -->
        </div><!-- card-body -->
    </div><!-- card -->

    <script src="<?php echo e(asset('dashboard/lib/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/lib/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- <script>
        'use script'

        var skinMode = localStorage.getItem('skin-mode');
        if (skinMode) {
            $('html').attr('data-skin', 'dark');
        }
    </script> -->


</body>

</html>
<?php /**PATH /Users/gursahb/Projects/Laravel/esol-test/resources/views/auth/login.blade.php ENDPATH**/ ?>