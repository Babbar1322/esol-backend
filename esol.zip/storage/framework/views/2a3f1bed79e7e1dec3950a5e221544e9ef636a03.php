<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-between mb-4">
        <div>
            <ol class="breadcrumb fs-sm mb-1">
                <li class="breadcrumb-item"><a>Test</a></li>
                <li class="breadcrumb-item">Add New Test</li>
                <li class="breadcrumb-item active" aria-current="page">Add Test Groups</li>
            </ol>
            <h4 class="main-title mb-0">Add Test Groups</h4>
        </div>
    </div>
    <div class="card card-one mt-3 shadow">
        <div class="card-body p-3">
            <?php if($data->count() > 0): ?>
                <h5>Already Added Groups</h5>
                <div class="alert alert-outline alert-secondary">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($group->group_name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if($errors->has('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e($errors->first('error')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('add-test-group')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="groupName" class="form-label">Group Name</label>
                    <input type="text" name="group_name" class="form-control" id="groupName"
                           placeholder="Enter Group Name">
                </div>
                <div class="mt-2">
                    <label for="groupName" class="form-label">Group Content</label>
                    <textarea class="form-control editor" name="group_content" rows="10" id="groupContent"
                              placeholder="Enter Group Content"></textarea>
                </div>
                <input type="hidden" name="test_id" value="<?php echo e($id); ?>">
                <div class="mt-2" id="newinput"></div>
                <div class="row justify-content-between">
                    <div class="col"><button type="submit" class="btn btn-primary w-25 mt-3">Submit</button></div>
                    <div class="col"><a href="<?php echo e(route('admin.add-test-questions', ['id' => $id])); ?>" class="btn btn-success w-25 mt-3 add-btn">Add Questions</a>
                    </div>
                </div>
                <!-- <div class="d-grid">
                            <button type="submit" class="btn btn-primary w-25 mt-3">Add</button>
                        </div> -->
            </form>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
    <script>
        $(document).ready(function() {
            // configure ckeditor
            CKEDITOR.replace('groupContent', {
                filebrowserUploadUrl: "",
                filebrowserUploadMethod: 'form'
            });
            // submit ckeditor data with form
            $('form').submit(function() {
                for (instance in CKEDITOR.instances) {
                    CKEDITOR.instances[instance].updateElement();
                }
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/gursahb/Projects/Laravel/esol-test/resources/views/dashboard/addTestGroups.blade.php ENDPATH**/ ?>